package com.risefit.app

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private val dayLabels = mapOf(7 to "ش", 1 to "ی", 2 to "د", 3 to "س", 4 to "چ", 5 to "پ", 6 to "ج")

private fun dayNames(days: List<Int>): String {
    if (days.size == 7) return "هر روز"
    return days.sorted().mapNotNull { dayLabels[it] }.joinToString("، ")
}

@Composable
fun RemindersScreen() {
    val reminders = remember { mutableStateListOf<Reminder>().also { it.addAll(Store.loadReminders()) } }
    fun persist() = Store.saveReminders(reminders.toList())
    var showAdd by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("یادآورها", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, contentDescription = "یادآور جدید") }
        }
        Text(
            "یادآور بیداری، مطالعه، باشگاه، فوتسال و… تنظیم کن.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        if (reminders.isEmpty()) Text("هنوز یادآوری نساختی — دکمه + رو بزن ⏰")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(reminders.size) { i ->
                val r = reminders[i]
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.title, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${toFa("%02d:%02d".format(r.hour, r.minute))} • ${dayNames(r.days)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = r.enabled,
                            onCheckedChange = { on ->
                                val nr = r.copy(enabled = on)
                                reminders[i] = nr
                                persist()
                                ReminderScheduler.schedule(Store.ctx, nr)
                            }
                        )
                        IconButton(onClick = {
                            val am = Store.ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                            am.cancel(ReminderScheduler.pi(Store.ctx, r.id))
                            reminders.removeAt(i)
                            persist()
                        }) { Icon(Icons.Default.Delete, contentDescription = "حذف") }
                    }
                }
            }
        }
    }
    if (showAdd) {
        ReminderDialog(
            onSave = { r ->
                reminders.add(r)
                persist()
                ReminderScheduler.schedule(Store.ctx, r)
                showAdd = false
            },
            onDismiss = { showAdd = false }
        )
    }
}

@Composable
fun ReminderDialog(onSave: (Reminder) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var h by remember { mutableIntStateOf(7) }
    var m by remember { mutableIntStateOf(0) }
    val dows = listOf(7, 1, 2, 3, 4, 5, 6)
    val labels = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")
    var days by remember { mutableStateOf(setOf(7, 1, 2, 3, 4, 5, 6)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("یادآور جدید") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("مثلاً: بیدارشدن / باشگاه") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Stepper("ساعت", h, 23, { h = it })
                    Stepper("دقیقه", m, 59, { m = it })
                }
                Text("روزهای تکرار", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    dows.forEachIndexed { idx, d ->
                        FilterChip(
                            selected = d in days,
                            onClick = { days = if (d in days) days - d else days + d },
                            label = { Text(labels[idx]) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (title.isNotBlank() && days.isNotEmpty())
                    onSave(Reminder(System.currentTimeMillis(), title.trim(), h, m, days.toList().sorted(), true))
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
