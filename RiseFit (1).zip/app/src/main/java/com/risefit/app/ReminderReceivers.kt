package com.risefit.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

object ReminderScheduler {
    fun pi(ctx: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, id.toInt(),
            Intent(ctx, ReminderReceiver::class.java).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun schedule(ctx: Context, r: Reminder) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = pi(ctx, r.id)
        if (!r.enabled || r.days.isEmpty()) {
            am.cancel(pending)
            return
        }
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, r.hour)
        cal.set(java.util.Calendar.MINUTE, r.minute)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        while (!r.days.contains(cal.get(java.util.Calendar.DAY_OF_WEEK)) ||
            cal.timeInMillis <= System.currentTimeMillis()
        ) cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.ctx = context.applicationContext
        val id = intent.getLongExtra("id", -1)
        val r = Store.loadReminders().firstOrNull { it.id == id } ?: return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("reminders", "یادآورها", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = NotificationCompat.Builder(context, "reminders")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("RiseFit")
            .setContentText(r.title)
            .setAutoCancel(true)
            .build()
        nm.notify(id.toInt(), notification)
        ReminderScheduler.schedule(context.applicationContext, r)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        Store.ctx = context.applicationContext
        Store.loadReminders().forEach { r ->
            if (r.enabled) ReminderScheduler.schedule(context.applicationContext, r)
        }
    }
}
