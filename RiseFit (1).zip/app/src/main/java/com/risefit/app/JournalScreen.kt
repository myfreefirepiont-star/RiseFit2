package com.risefit.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.LocalDate

@Composable
fun JournalScreen() {
    val notes = remember {
        mutableStateListOf<JournalNote>().also { it.addAll(Store.loadNotes().sortedByDescending { n -> n.id }) }
    }
    fun persist() = Store.saveNotes(notes.toList())
    var query by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<JournalNote?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("دفترچه شخصی", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = { editing = null; showAdd = true }) { Icon(Icons.Default.Add, contentDescription = "یادداشت جدید") }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            label = { Text("جست‌وجو…") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        val shown = if (query.isBlank()) notes else notes.filter { it.text.contains(query, ignoreCase = true) }
        if (shown.isEmpty()) Text("هنوز یادداشتی نداری — اولین خاطره یا ایده‌ات رو بنویس ✍️")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown.size) { i ->
                val n = shown[i]
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                jalali(LocalDate.ofEpochDay(n.epochDay)),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(n.text, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
                        }
                        IconButton(onClick = { editing = n; showAdd = true }) { Icon(Icons.Default.Edit, contentDescription = "ویرایش") }
                        IconButton(onClick = { notes.removeAll { it.id == n.id }; persist() }) { Icon(Icons.Default.Delete, contentDescription = "حذف") }
                    }
                }
            }
        }
    }
    if (showAdd) {
        NoteDialog(
            initial = editing,
            onSave = { note ->
                val idx = notes.indexOfFirst { it.id == note.id }
                if (idx >= 0) notes[idx] = note else notes.add(0, note)
                persist()
                showAdd = false
            },
            onDismiss = { showAdd = false }
        )
    }
}

@Composable
fun NoteDialog(initial: JournalNote?, onSave: (JournalNote) -> Unit, onDismiss: () -> Unit) {
    var text by remember(initial) { mutableStateOf(initial?.text ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "یادداشت جدید" else "ویرایش یادداشت") },
        text = {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                label = { Text("یادداشت، احساس، ایده یا آموخته‌ی امروز…") },
                minLines = 4, modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = {
                if (text.isNotBlank()) onSave(
                    JournalNote(initial?.id ?: System.currentTimeMillis(), initial?.epochDay ?: LocalDate.now().toEpochDay(), text.trim())
                )
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
