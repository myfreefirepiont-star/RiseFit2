package com.risefit.app

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class Task(
    val id: Long, val title: String, val category: String,
    val startHour: Int, val startMin: Int, val endHour: Int, val endMin: Int,
    val done: Boolean = false
)

data class Habit(val id: Long, val name: String, val entries: MutableMap<String, Boolean> = mutableMapOf())

data class GoalStep(val id: Long, val title: String, val done: Boolean = false)

data class Goal(
    val id: Long, val title: String, val targetDays: Int, val startEpochDay: Long,
    val steps: List<GoalStep> = emptyList(), val paused: Boolean = false
)

data class JournalNote(val id: Long, val epochDay: Long, val text: String)

data class Reminder(
    val id: Long, val title: String, val hour: Int, val minute: Int,
    val days: List<Int>, val enabled: Boolean = true
)

data class AiSettings(val apiUrl: String = "", val apiKey: String = "", val model: String = "")
data class Stats(val focusSessions: Int = 0, val focusMinutes: Int = 0)

object Store {
    lateinit var ctx: Context
    private val gson = Gson()
    private val prefs get() = ctx.getSharedPreferences("risefit", Context.MODE_PRIVATE)

    private fun put(key: String, v: Any) =
        prefs.edit().putString(key, gson.toJson(v)).apply()

    private inline fun <reified T> list(key: String): MutableList<T> {
        val s = prefs.getString(key, null) ?: return mutableListOf()
        return try {
            gson.fromJson(s, TypeToken.getParameterized(MutableList::class.java, T::class.java).type)!!
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun loadTasks() = list<Task>("tasks")
    fun saveTasks(v: List<Task>) = put("tasks", v)

    fun loadHabits() = list<Habit>("habits")
    fun saveHabits(v: List<Habit>) = put("habits", v)

    fun loadGoals() = list<Goal>("goals")
    fun saveGoals(v: List<Goal>) = put("goals", v)

    fun loadNotes() = list<JournalNote>("notes")
    fun saveNotes(v: List<JournalNote>) = put("notes", v)

    fun loadReminders() = list<Reminder>("reminders")
    fun saveReminders(v: List<Reminder>) = put("reminders", v)

    fun loadStats(): Stats {
        val s = prefs.getString("stats", null) ?: return Stats()
        return try { gson.fromJson(s, Stats::class.java) } catch (e: Exception) { Stats() }
    }
    fun saveStats(v: Stats) = put("stats", v)

    fun loadAi(): AiSettings {
        val s = prefs.getString("ai", null) ?: return AiSettings()
        return try { gson.fromJson(s, AiSettings::class.java) } catch (e: Exception) { AiSettings() }
    }
    fun saveAi(v: AiSettings) = put("ai", v)
}
