package com.risefit.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.LocalDate

@Composable
fun GoalsScreen() {
    val goals = remember { mutableStateListOf<Goal>().also { it.addAll(Store.loadGoals()) } }
    fun persist() = Store.saveGoals(goals.toList())
    var showAdd by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("اهداف", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, contentDescription = "افزودن هدف") }
        }
        if (goals.isEmpty()) Text("یک هدف ۳۰، ۶۰ یا ۱۰۰ روزه بساز و اون رو به قدم‌های کوچک تقسیم کن 🎯")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(goals.size) { i ->
                val g = goals[i]
                val elapsed = ((LocalDate.now().toEpochDay() - g.startEpochDay).toInt() + 1).coerceAtLeast(1)
                val total = g.steps.size
                val doneSteps = g.steps.count { it.done }
                val pct = if (total == 0) 0f else doneSteps.toFloat() / total
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(g.title, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    when {
                                        g.paused -> "متوقف شده ⏸"
                                        elapsed >= g.targetDays -> "🎉 دوره‌ی ${toFa(g.targetDays)} روزه تمام شد!"
                                        else -> "روز ${toFa(elapsed)} از ${toFa(g.targetDays)}"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { goals[i] = g.copy(paused = !g.paused); persist() }) {
                                Icon(if (g.paused) Icons.Default.PlayArrow else Icons.Default.Pause, contentDescription = "توقف/ادامه")
                            }
                            IconButton(onClick = { goals.removeAt(i); persist() }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف")
                            }
                        }
                        LinearProgressIndicator(
                            progress = { pct },
                            modifier = Modifier.fillMaxWidth().height(6.dp)
                        )
                        Text(
                            "پیشرفت: ${toFa((pct * 100).toInt())}٪ • قدم‌ها: ${toFa(doneSteps)} از ${toFa(total)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        g.steps.forEachIndexed { j, s ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = s.done,
                                    onCheckedChange = {
                                        goals[i] = g.copy(steps = g.steps.mapIndexed { k, x -> if (k == j) x.copy(done = !x.done) else x })
                                        persist()
                                    }
                                )
                                Text(s.title, Modifier.weight(1f))
                                IconButton(onClick = { goals[i] = g.copy(steps = g.steps.filterIndexed { k, _ -> k != j }); persist() }) {
                                    Icon(Icons.Default.Close, contentDescription = "حذف قدم", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            var st by remember(g.id) { mutableStateOf("") }
                            OutlinedTextField(
                                value = st, onValueChange = { st = it },
                                label = { Text("قدم جدید") }, singleLine = true, modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = {
                                if (st.isNotBlank()) {
                                    goals[i] = g.copy(steps = g.steps + GoalStep(System.currentTimeMillis(), st.trim()))
                                    persist()
                                }
                            }) { Icon(Icons.Default.Add, contentDescription = "افزودن قدم") }
                        }
                    }
                }
            }
        }
    }
    if (showAdd) {
        GoalDialog(
            onSave = { g -> goals.add(g); persist(); showAdd = false },
            onDismiss = { showAdd = false }
        )
    }
}

@Composable
fun GoalDialog(onSave: (Goal) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var days by remember { mutableIntStateOf(30) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("هدف جدید") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text("مثلاً: ۱۰ کیلو کاهش وزن") }, singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(30, 60, 100).forEach { d ->
                        FilterChip(selected = days == d, onClick = { days = d }, label = { Text(toFa(d) + " روزه") })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (title.isNotBlank()) onSave(Goal(System.currentTimeMillis(), title.trim(), days, LocalDate.now().toEpochDay()))
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
