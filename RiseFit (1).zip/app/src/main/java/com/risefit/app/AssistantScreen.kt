package com.risefit.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private data class Msg(val role: String, val content: String)

@Composable
fun AssistantScreen() {
    var ai by remember { mutableStateOf(Store.loadAi()) }
    var showSettings by remember { mutableStateOf(Store.loadAi().apiUrl.isBlank()) }
    val msgs = remember {
        mutableStateListOf<Msg>().also {
            it.add(Msg("assistant", "سلام! من RiseAI هستم 🤖 درباره‌ی درس، تمرین، برنامه‌ریزی و مدیریت زمان ازم بپرس."))
        }
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var offlineNote by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("دستیار RiseAI", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = { showSettings = !showSettings }) { Icon(Icons.Default.Settings, contentDescription = "تنظیمات") }
        }
        if (showSettings) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("تنظیمات سرویس هوش مصنوعی", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(
                        value = ai.apiUrl, onValueChange = { ai = ai.copy(apiUrl = it) },
                        label = { Text("آدرس سرویس (مثلاً https://api.openai.com/v1/chat/completions)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = ai.apiKey, onValueChange = { ai = ai.copy(apiKey = it) },
                        label = { Text("کلید API") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = ai.model, onValueChange = { ai = ai.copy(model = it) },
                        label = { Text("نام مدل (مثلاً gpt-4o-mini)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Button(onClick = { Store.saveAi(ai); showSettings = false }) { Text("ذخیره تنظیمات") }
                    Text(
                        "کلید فقط روی گوشی خودت ذخیره می‌شود و هرگز داخل کد یا فایل APK قرار نمی‌گیرد. اتصال مستقیم فقط با سرویس‌های دارای HTTPS کار می‌کند.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { m -> Bubble(m) }
            if (busy) {
                item { Text("در حال نوشتن…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
        if (offlineNote) {
            Text(
                "اتصال به سرویس برقرار نشد؛ پاسخ آفلاین داده شد.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                label = { Text("سؤالت رو بنویس…") },
                singleLine = true, modifier = Modifier.weight(1f)
            )
            Button(
                onClick = {
                    val q = input.trim()
                    if (q.isEmpty() || busy) return@Button
                    msgs.add(Msg("user", q))
                    input = ""
                    busy = true
                    offlineNote = false
                    scope.launch {
                        val reply = if (ai.apiUrl.isBlank()) {
                            localReply(q)
                        } else {
                            askAi(ai, msgs.toList()) ?: run { offlineNote = true; localReply(q) }
                        }
                        msgs.add(Msg("assistant", reply))
                        busy = false
                    }
                },
                enabled = !busy
            ) { Icon(Icons.Default.Send, contentDescription = "ارسال") }
        }
    }
}

@Composable
private fun Bubble(m: Msg) {
    val isUser = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Text(
                m.content, Modifier.padding(10.dp),
                color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

private fun localReply(q: String): String = when {
    q.contains("برنامه") -> "پیشنهاد: کارهای امروزت رو بر اساس اولویت مرتب کن و برای هر کدوم بازه‌ی زمانی مشخص بذار؛ در بخش «برنامه» می‌تونی این کار رو انجام بدی."
    q.contains("درس") || q.contains("مطالعه") -> "برای مطالعه، روش پومودورو (۲۵ دقیقه تمرکز + ۵ دقیقه استراحت) رو امتحان کن؛ تایمر تمرکز RiseFit دقیقاً برای همین ساخته شده."
    q.contains("انگیزه") -> "استمرار از تکرارهای کوچک ساخته می‌شه. حتی ۱۰ دقیقه امروز بهتر از صفرِ فرداست! 💪"
    q.contains("هدف") -> "هدف‌های بزرگ رو به قدم‌های کوچک بشکن؛ در بخش «اهداف» هر هدف رو به چند قدم کوتاه تقسیم کن و هر روز یکی رو تیک بزن."
    else -> "پیامت ثبت شد. برای پاسخ کامل‌تر، در تنظیمات دستیار آدرس سرویس و کلید API رو وارد کن؛ در حالت آفلاین فقط پیشنهادهای پایه در دسترسه."
}

private suspend fun askAi(s: AiSettings, msgs: List<Msg>): String? = withContext(Dispatchers.IO) {
    try {
        val conn = (URL(s.apiUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 90000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer " + s.apiKey)
        }
        val root = JsonObject()
        root.addProperty("model", s.model.ifBlank { "gpt-4o-mini" })
        val arr = JsonArray()
        val sys = JsonObject()
        sys.addProperty("role", "system")
        sys.addProperty(
            "content",
            "تو دستیار فارسی اپلیکیشن RiseFit هستی؛ به سؤالات کاربر درباره درس، تمرین، برنامه‌ریزی و مدیریت زمان پاسخ کوتاه و کاربردی به زبان فارسی بده."
        )
        arr.add(sys)
        msgs.forEach { m ->
            val o = JsonObject()
            o.addProperty("role", m.role)
            o.addProperty("content", m.content)
            arr.add(o)
        }
        root.add("messages", arr)
        conn.outputStream.use { it.write(root.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) return@withContext null
        JsonParser.parseString(body).asJsonObject
            .getAsJsonArray("choices")[0].asJsonObject
            .getAsJsonObject("message")["content"].asString
    } catch (e: Exception) {
        null
    }
}
