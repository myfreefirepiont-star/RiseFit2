package com.risefit.app

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun TimerScreen() {
    var preset by remember { mutableIntStateOf(25) }
    var remaining by remember { mutableIntStateOf(25 * 60) }
    var running by remember { mutableStateOf(false) }
    var isBreak by remember { mutableStateOf(false) }
    var stats by remember { mutableStateOf(Store.loadStats()) }

    LaunchedEffect(running) {
        while (running && remaining > 0) {
            delay(1000)
            remaining--
        }
        if (running && remaining <= 0) {
            running = false
            if (!isBreak) {
                stats = stats.copy(focusSessions = stats.focusSessions + 1, focusMinutes = stats.focusMinutes + preset)
                Store.saveStats(stats)
                isBreak = true
                remaining = 5 * 60
            } else {
                isBreak = false
                remaining = preset * 60
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("تایمر تمرکز", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(24.dp))
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = {
                    if (isBreak) 1f - remaining / 300f
                    else 1f - remaining / (preset * 60f)
                },
                modifier = Modifier.size(220.dp),
                strokeWidth = 10.dp
            )
            Text(toFa("%02d:%02d".format(remaining / 60, remaining % 60)), style = MaterialTheme.typography.displayLarge)
        }
        Spacer(Modifier.height(24.dp))
        if (!running) {
            Text(if (isBreak) "زمان استراحت" else "مدت جلسه", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15, 25, 45, 90).forEach { p ->
                    FilterChip(
                        selected = preset == p && !isBreak,
                        onClick = { if (!running && !isBreak) { preset = p; remaining = p * 60 } },
                        label = { Text(toFa(p) + " دقیقه") }
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { running = !running }, enabled = remaining > 0) {
                Icon(if (running) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(when {
                    running -> "توقف"
                    remaining < (if (isBreak) 300 else preset * 60) -> "ادامه"
                    else -> "شروع"
                })
            }
            OutlinedButton(onClick = { running = false; isBreak = false; remaining = preset * 60 }) { Text("لغو") }
        }
        Spacer(Modifier.weight(1f))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("آمار تمرکز", style = MaterialTheme.typography.titleSmall)
                Text("جلسات تکمیل‌شده: ${toFa(stats.focusSessions)}", style = MaterialTheme.typography.bodyMedium)
                Text("مجموع زمان تمرکز: ${toFa(stats.focusMinutes)} دقیقه", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
