package com.risefit.app

import java.time.LocalDate

fun toFa(s: String): String {
    val d = "۰۱۲۳۴۵۶۷۸۹"
    return s.map { if (it in '0'..'9') d[it - '0'] else it }.joinToString("")
}

fun toFa(n: Int): String = toFa(n.toString())

private val jalaliMonths = listOf(
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
)

fun jalali(date: LocalDate): String {
    val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
    val gy = date.year
    val gm = date.monthValue
    val gd = date.dayOfMonth
    var jy = if (gy <= 1600) 0 else 979
    val gy2 = if (gy <= 1600) gy - 621 else gy - 1600
    val gy3 = if (gm > 2) gy2 + 1 else gy2
    var days = 365L * gy2 + (gy3 + 3) / 4 - (gy3 + 99) / 100 + (gy3 + 399) / 400 - 80 + gd + gdm[gm - 1]
    jy += 33 * (days / 12053).toInt(); days %= 12053
    jy += 4 * (days / 1461).toInt(); days %= 1461
    if (days > 365) {
        jy += ((days - 1) / 365).toInt()
        days = (days - 1) % 365
    }
    val jm = if (days < 186) 1 + days / 31 else 7 + (days - 186) / 30
    val jd = if (days < 186) 1 + days % 31 else 1 + (days - 186) % 30
    return "${toFa(jd.toInt())} ${jalaliMonths[(jm - 1).toInt()]} ${toFa(jy.toString())}"
}
