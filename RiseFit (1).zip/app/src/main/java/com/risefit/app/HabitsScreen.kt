package com.risefit.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import java.time.LocalDate

@Composable
fun HabitsScreen() {
    val habits = remember { mutableStateListOf<Habit>().also { it.addAll(Store.loadHabits()) } }
    fun persist() = Store.saveHabits(habits.toList())
    var newName by remember { mutableStateOf("") }
    val today = LocalDate.now()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("پیگیری عادت‌ها", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = newName, onValueChange = { newName = it },
                label = { Text("عادت جدید") }, singleLine = true, modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                if (newName.isNotBlank()) {
                    habits.add(Habit(System.currentTimeMillis(), newName.trim()))
                    newName = ""
                    persist()
                }
            }) {
                Icon(Icons.Default.Add, contentDescription = null)
                Text("افزودن")
            }
        }
        Spacer(Modifier.height(8.dp))
        if (habits.isEmpty()) Text("هنوز عادتی نساختی. مثلاً «۱۵ دقیقه کتاب‌خوانی» رو اضافه کن 🌱")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(habits) { i, h ->
                HabitCard(
                    h = h,
                    onToggle = {
                        val key = today.toString()
                        val map = h.entries.toMutableMap()
                        if (map[key] == true) map.remove(key) else map[key] = true
                        habits[i] = h.copy(entries = map)
                        persist()
                    },
                    onDelete = { habits.removeAt(i); persist() }
                )
            }
        }
    }
}

private fun streak(h: Habit): Int {
    var d = LocalDate.now()
    var s = 0
    while (h.entries[d.toString()] == true) {
        s++
        d = d.minusDays(1)
    }
    return s
}

@Composable
fun HabitCard(h: Habit, onToggle: () -> Unit, onDelete: () -> Unit) {
    val today = LocalDate.now()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(h.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "استمرار: ${toFa(streak(h))} روز",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Checkbox(checked = h.entries[today.toString()] == true, onCheckedChange = { onToggle() })
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "حذف") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (6 downTo 0).forEach { off ->
                    val d = today.minusDays(off.toLong())
                    val done = h.entries[d.toString()] == true
                    Box(
                        Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    )
                }
            }
        }
    }
}
