package com.risefit.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp

@Composable
fun PlannerScreen() {
    val tasks = remember { mutableStateListOf<Task>().also { it.addAll(Store.loadTasks()) } }
    fun persist() = Store.saveTasks(tasks.toList())
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Task?>(null) }
    val done = tasks.count { it.done }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("دفتر برنامه روزانه", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = { editing = null; showAdd = true }) {
                Icon(Icons.Default.Add, contentDescription = "افزودن کار")
            }
        }
        Text(
            "پیشرفت امروز: ${toFa(done)} از ${toFa(tasks.size)}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        LinearProgressIndicator(
            progress = { if (tasks.isEmpty()) 0f else done.toFloat() / tasks.size },
            modifier = Modifier.fillMaxWidth().height(8.dp)
        )
        Spacer(Modifier.height(12.dp))
        if (tasks.isEmpty()) Text("امروز برنامه‌ای نداری — اولین کار روزت رو اضافه کن ✨")
        val sorted = tasks.sortedBy { it.startHour * 60 + it.startMin }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(sorted.size) { i ->
                val t = sorted[i]
                TaskRow(
                    t = t,
                    onToggle = {
                        val idx = tasks.indexOfFirst { it.id == t.id }
                        if (idx >= 0) { tasks[idx] = tasks[idx].copy(done = !tasks[idx].done); persist() }
                    },
                    onEdit = { editing = t; showAdd = true },
                    onDelete = { tasks.removeAll { it.id == t.id }; persist() }
                )
            }
        }
    }
    if (showAdd) {
        TaskDialog(
            initial = editing,
            onSave = { nt ->
                val idx = tasks.indexOfFirst { it.id == nt.id }
                if (idx >= 0) tasks[idx] = nt else tasks.add(nt)
                persist()
                showAdd = false
            },
            onDismiss = { showAdd = false }
        )
    }
}

@Composable
fun TaskRow(t: Task, onToggle: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = t.done, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(
                    t.title,
                    style = MaterialTheme.typography.bodyLarge,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null
                )
                Text(
                    "${t.category} • ${toFa("%d:%02d".format(t.startHour, t.startMin))} تا ${toFa("%d:%02d".format(t.endHour, t.endMin))}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "ویرایش") }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "حذف") }
        }
    }
}

@Composable
fun Stepper(label: String, value: Int, max: Int, onChange: (Int) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onChange(if (value <= 0) max else value - 1) }) {
                Icon(Icons.Default.Remove, contentDescription = "کمتر")
            }
            Text(toFa("%02d".format(value)), style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = { onChange(if (value >= max) 0 else value + 1) }) {
                Icon(Icons.Default.Add, contentDescription = "بیشتر")
            }
        }
    }
}

@Composable
fun TaskDialog(initial: Task?, onSave: (Task) -> Unit, onDismiss: () -> Unit) {
    val cats = listOf("درس", "مدرسه", "بدنسازی", "فوتسال", "استراحت", "شخصی")
    var title by remember(initial) { mutableStateOf(initial?.title ?: "") }
    var cat by remember(initial) { mutableStateOf(initial?.category ?: "درس") }
    var sh by remember(initial) { mutableIntStateOf(initial?.startHour ?: 8) }
    var sm by remember(initial) { mutableIntStateOf(initial?.startMin ?: 0) }
    var eh by remember(initial) { mutableIntStateOf(initial?.endHour ?: 9) }
    var em by remember(initial) { mutableIntStateOf(initial?.endMin ?: 0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "کار جدید" else "ویرایش کار") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("عنوان") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    cats.forEach { c ->
                        FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Stepper("ساعت شروع", sh, 23, { sh = it })
                    Stepper("دقیقه", sm, 59, { sm = it })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Stepper("ساعت پایان", eh, 23, { eh = it })
                    Stepper("دقیقه", em, 59, { em = it })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (title.isNotBlank()) onSave(
                    Task(initial?.id ?: System.currentTimeMillis(), title.trim(), cat, sh, sm, eh, em, initial?.done ?: false)
                )
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
