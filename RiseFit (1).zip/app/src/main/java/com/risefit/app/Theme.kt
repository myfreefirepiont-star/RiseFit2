package com.risefit.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

val NeonPurple = Color(0xFFA855F7)
val DeepPurple = Color(0xFF7C3AED)
val RiseBg = Color(0xFF0B0B12)
val RiseSurface = Color(0xFF171722)
val RiseText = Color(0xFFEDEDF5)

@Composable
fun RiseTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = NeonPurple,
            onPrimary = Color.White,
            secondary = Color(0xFFC084FC),
            background = RiseBg,
            onBackground = RiseText,
            surface = RiseSurface,
            onSurface = RiseText,
            surfaceVariant = Color(0xFF1F1F2E),
            onSurfaceVariant = Color(0xFFB9B9CC),
            error = Color(0xFFF87171)
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            content()
        }
    }
}
